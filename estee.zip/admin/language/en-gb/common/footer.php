<?php
// Text
$_['text_footer']  = '<a href="https://www.firstcom.com.sg/" target="_blank" >Firstcom Solutions</a> &copy; 2009-' . date('Y') . ' All Rights Reserved.';
$_['text_version'] = 'Version %s';