<?php
$_['heading_title']    = 'Auto Resizer';
$_['text_edit']        = 'AutoResizer';
$_['entry_width']      = 'maxWidth';
$_['entry_height']     = 'maxHeight';
$_['entry_quality']    = 'Image Quality';

$_['button_save']      = 'Save';
$_['button_cancel']    = 'Cancel';
$_['entry_status']     = 'Status';
$_['text_success']     = 'Success: You have modified module AutoResize!';
?>